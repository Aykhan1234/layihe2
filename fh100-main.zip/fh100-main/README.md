# valyuta_changes_new
# valyuta_change
